# -*- coding: utf-8 -*-

import os
import cPickle as pickle
import time
import matplotlib.pyplot as plt
import numpy as np
from GlobalParam import *
from LoadData import unpickling


# bin_file list를 전달받아
# 각각의 bin_file을 그래프로 보여줌
def bins2graphs(path, file_list):
    old_path = os.getcwd()

    path = os.path.join(path, RESULT_DIRECTORY, 'graph')
    if not os.path.exists(path):
        os.makedirs(path)
    os.chdir(path)

    for file in file_list:
        print 'vector2graph ' + file,
        start_time = time.time()

        x = []
        for line in unpickling(file)['ts']:
            x.append(line[0])
        y = unpickling(file)['value']

        plt.scatter(x, y, marker='x')

        file_name = file.rsplit('/', 1)[1]

        file_name = file_name.split('.')[0] + '.jpg'

        plt.show(file_name)
        plt.close()

        end_time = time.time()
        print '\t\t' + 'run time: ' + str(end_time - start_time)

    os.chdir(old_path)