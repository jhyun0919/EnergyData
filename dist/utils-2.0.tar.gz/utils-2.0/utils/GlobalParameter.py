# -*- coding: utf-8 -*-

Level = 9
Interpolation_Interval = 10     # minute
Noise_Filter = 10
Scale_Size = Level * 10
N_Neighbor = 30
Knn_Weights = 'uniform'