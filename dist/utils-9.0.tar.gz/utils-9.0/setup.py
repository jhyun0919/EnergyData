from distutils.core import setup

setup(
    name="utils",
    version="9.0",
    description="Energy Data Management System",
    author="Park Jee Hyun",
    author_email="jhyun19@gmail.com",
    packages=['utils']
)