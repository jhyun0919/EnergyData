from distutils.core import setup

setup(
    name="utils",
    version="4.1",
    # py_modules=['./utils/Dependency', './utils/Graph'],
    description="Energy Data Management",
    author="Park Jee Hyun",
    author_email="jhyun19@gmail.com",
    packages=['utils']
)
