from distutils.core import setup

setup(
    name="utils",
    version="5.3",
    description="Energy Data Management",
    author="Park Jee Hyun",
    author_email="jhyun19@gmail.com",
    packages=['utils']
)
