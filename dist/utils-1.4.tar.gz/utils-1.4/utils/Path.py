# -*- coding: utf-8 -*-

import os


def path_checker(directory):
    if os.path.isdir(directory):
        return directory
    else:
        directory = directory.rsplit('/', 1)[0]
        path_checker(directory)


