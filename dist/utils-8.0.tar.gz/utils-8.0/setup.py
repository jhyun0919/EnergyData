from distutils.core import setup

setup(
    name="utils",
    version="8.0",
    description="Energy Data Management",
    author="Park Jee Hyun",
    author_email="jhyun19@gmail.com",
    packages=['utils']
)
